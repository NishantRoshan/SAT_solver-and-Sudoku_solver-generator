Put the cnf file as the input in the code. It will be read by the Dimacs to Vector file. Then it will be converted to a vector of clauses and will output the required model.
